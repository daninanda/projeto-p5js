//definir variaveis globais
let jardineiro;
let plantas= [];
let temperatura = 10;
let totalArvores = 0;

// Definição da classe Jardineiro (assumindo que exista e tenha um construtor que aceite x e y)
class Jardineiro {
  constructor(x, y) {
    this.x = x;
    this.y = y;
    this.velocidade = 5; // Defina uma velocidade padrão
  }

  mostrar() {
    fill('green'); // Cor do jardineiro (pode ser alterada)
    ellipse(this.x, this.y, 20, 40); // Desenha o jardineiro (pode ser alterado)
  }

  atualizar() {
    if (keyIsDown(LEFT_ARROW)) {
      this.x -= this.velocidade;
    }
    if (keyIsDown(RIGHT_ARROW)) {
      this.x += this.velocidade;
    }
    if (keyIsDown(UP_ARROW)) {
      this.y -= this.velocidade;
    }
    if (keyIsDown(DOWN_ARROW)) {
      this.y += this.velocidade;
    }
  }
}

// Definição da classe Arvore (assumindo que exista e tenha um construtor que aceite x e y)
class Arvore {
  constructor(x, y) {
    this.x = x;
    this.y = y;
    this.tamanho = 20; // Tamanho da árvore (pode ser alterado)
  }

  mostrar() {
    fill('brown'); // Cor do tronco
    rect(this.x - this.tamanho / 4, this.y - this.tamanho, this.tamanho / 2, this.tamanho);
    fill('green'); // Cor das folhas
    ellipse(this.x, this.y - this.tamanho, this.tamanho, this.tamanho);
  }
}

function setup() {
  createCanvas(600, 400);
  jardineiro = new Jardineiro(width / 2, height - 50); // 
}

function draw() {
  //Usando map()para ajustar a cor de fundo de forma masi controlada
  let corFundo = lerpColor(color(217, 112, 26), color(219, 239, 208), map(totalArvores, 0, 100, 0, 1));
  background(corFundo);
  mostrarInformacoes();
  temperatura += 0.1;
  jardineiro.atualizar(); // Chamada para o método 'atualizar' do objeto jardineiro
  jardineiro.mostrar();
  //Verifica se o jogo acabou
  verificarFimDeJogo();
  //Usando map()para aplicar o comportamento de árvores plantadas
  plantas.map((arvore) => arvore.mostrar());
}
// Função para mostrar as infomações na tela
function mostrarInformacoes() {
  textSize(26); // Correção: 'textSize' com 's' minúsculo
  fill(0);
  text("Vamos plantar arvores para reduzir temperatura?", 10, 30);
  textSize(14);
  fill('white');
  text("temperatura:" + temperatura.toFixed(2), 10, 390);
  text("Árvores plantadas:" + totalArvores, 460, 390);
  text("Para movimentar o personagem use as setas do teclado.", 10, 60);
  text("Para plantae árvores use P ou espaço.", 10, 80);
}

//Função para verificar se o jogo acabou
function verificarFimDeJogo() {
  if (totalArvores > temperatura) {
    mostrarMensagemDeVitoria();
  } else if (temperatura > 50) {
    mostrarMensagemDeDerrota();
  }
}

// Função para mostrar mensagem de vitória (você precisará implementá-la)
function mostrarMensagemDeVitoria() {
  textSize(32);
  fill('green');
  text("Você venceu! Temperatura reduzida.", width / 2 - 200, height / 2);
  noLoop(); // Para o loop do draw
}

// Função para mostrar mensagem de derrota (você precisará implementá-la)
function mostrarMensagemDeDerrota() {
  textSize(32);
  fill('red');
  text("Você perdeu! Temperatura muito alta.", width / 2 - 200, height / 2);
  noLoop(); // Para o loop do draw
}

// Função para criar e plantar uma árvore
function keyPressed() {
  if (key === ' ' || key === 'p') {
    let arvore = new Arvore(jardineiro.x, jardineiro.y);
    plantas.push(arvore);
    totalArvores++;
    temperatura -= 3;
    if (temperatura < 0) temperatura = 0;
  }
}